#include "util.h"

int* read_next_line(FILE* fin) {
    char buffer[1024];

    if (fgets(buffer, sizeof(buffer), fin) == NULL) {
        return NULL;
    }

    int count = 1;
    for (int i = 0; buffer[i] != '\0'; i++) {
        if (buffer[i] == ',') {
            count++;
        }
    }

    int* line = malloc((count + 1) * sizeof(int));
    if (line == NULL) {
        return NULL;
    }

    line[0] = count;

    char* token = strtok(buffer, ",\n");
    int index = 1;

    while (token != NULL) {
        line[index] = atoi(token);
        index++;
        token = strtok(NULL, ",\n");
    }

    return line;
}


float compute_average(int* line) {
    int count = line[0];
    int sum = 0;

    for (int i = 1; i <= count; i++) {
        sum += line[i];
    }

    return (float)sum / count;
}


float compute_stdev(int* line) {
    int count = line[0];
    float avg = compute_average(line);
    float sum = 0;

    for (int i = 1; i <= count; i++) {
        float diff = line[i] - avg;
        sum += diff * diff;
    }

    return sqrt(sum / count);
}